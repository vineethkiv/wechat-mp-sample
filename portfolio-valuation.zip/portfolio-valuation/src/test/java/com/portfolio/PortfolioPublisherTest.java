/**
 * 
 */
package com.portfolio;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.junit.Before;
import org.junit.Test;

import com.portfolio.model.Option;
import com.portfolio.model.Portfolio;
import com.portfolio.model.Position;
import com.portfolio.model.Security;
import com.portfolio.model.Stock;
import com.portfolio.service.PortfolioPublisher;
import com.portfolio.util.CsvPortfolioReader;

/**
 * 
 */
public class PortfolioPublisherTest {

	private PortfolioPublisher portfolioPublisher;
	private BlockingQueue<Map<String, Double>> testMdQueue;
	private BlockingQueue<Portfolio> testPfQueue;

	@Before
	public void setUp() throws InterruptedException {

		Map<String, Security> stockUniverse = new HashMap<String, Security>();
		stockUniverse.put("AAPL220319C00180000",
				new Option("AAPL220319C00180000", "Call", 1.0, 115.0, 0.65, new Stock("AAPL", 110.0, .04, .2)));

		Portfolio pf = CsvPortfolioReader.readPortfolioPositions(stockUniverse);
		List<Position> pos = pf.getPositions();

		Map<String, Double> testMd = new HashMap<String, Double>();
		testMd.put("AAPL", 110.0);
		testMdQueue = new ArrayBlockingQueue<>(10);
		testMdQueue.put(testMd);
		testPfQueue = new ArrayBlockingQueue<>(10);

		portfolioPublisher = new PortfolioPublisher(pos, testMdQueue, testPfQueue);
	}

	@Test
	public void testPortfolioPublisher() throws InterruptedException {
		Thread thread = new Thread(portfolioPublisher);
		thread.start();

		Thread.sleep(5000);
		thread.interrupt();
		thread.join();

		Portfolio testResult = testPfQueue.take();
		Position pos = testResult.getPositions().get(0);
		assertNotNull(testResult);
		assertTrue(pos.getSecurity().getPrice() > 1.0);
		assertEquals("Call price is not within the expected range", 5.56, pos.getSecurity().getPrice(), 0.001);

	}

}
