/**
 * 
 */
package com.portfolio;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;

import com.portfolio.model.Security;
import com.portfolio.model.Stock;
import com.portfolio.service.MarketDataPublisher;

/**
 * 
 */
public class MarketDataTest {

	private MarketDataPublisher marketDataPublisher;
	private BlockingQueue<Map<String, Double>> testQueue;

	@Before
	public void setUp() {
		Map<String, Security> stockUniverse = new HashMap<String, Security>();
		stockUniverse.put("AAPL", new Stock("AAPL", 180.0, .04, .3));
		stockUniverse.put("TSLA", new Stock("TSLA", 450.0, .07, .4));
		stockUniverse.put("GOOG", new Stock("GOOG", 130.0, .02, .2));

		List<Stock> stockPool = stockUniverse.entrySet().stream().filter(entry -> entry.getValue() instanceof Stock)
				.map(entry -> (Stock) entry.getValue()).collect(Collectors.toList());

		testQueue = new ArrayBlockingQueue<>(10);

		marketDataPublisher = new MarketDataPublisher(stockPool, testQueue);
	}

	@Test
	public void testMarketDataPublisher() throws InterruptedException {
		Thread thread = new Thread(marketDataPublisher);
		thread.start();

		Thread.sleep(5000);
		thread.interrupt();
		thread.join();

		Map<String, Double> testResult = testQueue.take();
		assertNotNull(testResult);
		assertTrue(testResult.size() > 1);

	}

}
