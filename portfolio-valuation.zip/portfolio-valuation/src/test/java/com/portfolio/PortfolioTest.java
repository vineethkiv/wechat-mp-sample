/**
 * 
 */
package com.portfolio;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.portfolio.model.Option;
import com.portfolio.model.Portfolio;
import com.portfolio.model.Position;
import com.portfolio.model.Security;
import com.portfolio.model.Stock;
import com.portfolio.service.OptionPricing;
import com.portfolio.util.CsvPortfolioReader;

/**
 * 
 */
public class PortfolioTest {
	
	@Test
	public void testNav() throws Exception {

		Map<String, Security> stockUniverse = new HashMap<String, Security>();
		stockUniverse.put("AAPL", new Stock("AAPL", 110.0, .04, .2));
		stockUniverse.put("TSLA", new Stock("TSLA", 450.0, .07, .4));
		stockUniverse.put("AAPL220319C00180000",
				new Option("AAPL220319C00180000", "Call", 1.0, 115.0, 0.65, new Stock("AAPL", 110.0, .04, .2)));
		stockUniverse.put("AAPL220319P00180000",
				new Option("AAPL220319P00180000", "Put", 1.0, 105.0, 0.07, new Stock("AAPL", 110.0, .04, .2)));
		stockUniverse.put("TSLA210319C00300000",
				new Option("TSLA210319C00300000", "Call", 1.0, 460.0, .185, new Stock("TSLA", 450.0, .07, .4)));
		stockUniverse.put("TSLA210319P00300000",
				new Option("TSLA210319P00300000", "Put", 1.0, 440.0, .023, new Stock("TSLA", 450.0, .07, .4)));

		Portfolio pf = CsvPortfolioReader.readPortfolioPositions(stockUniverse);
		List<Position> pos = pf.getPositions();
		
		for (Position position : pos) {
			if (position.getSecurity() instanceof Option) {
				Option op = (Option) position.getSecurity();
				double newPrice = 0.0;
				if (op.getType().equals("Call")) {
					newPrice = OptionPricing.calculateCallPrice(op.getUnderlying().getPrice(), op.getStrike(),
							op.getMaturity(), op.getUnderlying().getSigma());
				} else if (op.getType().equals("Put")) {
					newPrice = OptionPricing.calculatePutPrice(op.getUnderlying().getPrice(), op.getStrike(),
							op.getMaturity(), op.getUnderlying().getSigma());
				}
				op.setPrice(newPrice);
			}
		}
		
		double totalVal = 0.0;
		for (Position position : pf.getPositions()) {
			int qty = position.getQuantity();
			Security s = position.getSecurity();
			double price = s.getPrice();
			double value = Math.round(price * 100.0)/100.0 * qty;
			totalVal += value;
		}

		assertEquals("NAV is not within the expected range", -7600.00, totalVal, 1.0);

	}

	@Test
	public void testReadPositionsWithStockOnlyUniverse() throws Exception {

		Map<String, Security> stockUniverse = new HashMap<String, Security>();
		stockUniverse.put("AAPL", new Stock("AAPL", 180.0, .04, .3));
		stockUniverse.put("TSLA", new Stock("TSLA", 450.0, .07, .4));
		stockUniverse.put("GOOG", new Stock("GOOG", 130.0, .02, .2));

		Portfolio pf = CsvPortfolioReader.readPortfolioPositions(stockUniverse);
		List<Position> pos = pf.getPositions();

		assertEquals(2, pos.size());
		assertEquals("AAPL", pos.get(0).getSecurity().getTicker());
		assertEquals(1000, pos.get(0).getQuantity());
		assertEquals("TSLA", pos.get(1).getSecurity().getTicker());
		assertEquals(-500, pos.get(1).getQuantity());

	}
	
	@Test
	public void testReadPositionsWithOptionOnlyUniverse() throws Exception {

		Map<String, Security> stockUniverse = new HashMap<String, Security>();
		stockUniverse.put("AAPL220319C00180000",
				new Option("AAPL220319C00180000", "Call", 0, 0, 0, new Stock("AAPL", 130.0, .02, .2)));
		stockUniverse.put("TSLA210319P00300000",
				new Option("TSLA210319P00300000", "Put", 0, 0, 0, new Stock("TSLA", 130.0, .02, .2)));

		Portfolio pf = CsvPortfolioReader.readPortfolioPositions(stockUniverse);
		List<Position> pos = pf.getPositions();

		assertEquals(2, pos.size());
		assertEquals("AAPL220319C00180000", pos.get(0).getSecurity().getTicker());
		assertEquals(-20000, pos.get(0).getQuantity());
		assertEquals("TSLA210319P00300000", pos.get(1).getSecurity().getTicker());
		assertEquals(-10000, pos.get(1).getQuantity());

	}

	@Test
	public void testReadPositionsWithStockOptionUniverse() throws Exception {

		Map<String, Security> stockUniverse = new HashMap<String, Security>();
		stockUniverse.put("AAPL", new Stock("AAPL", 180.0, .04, .3));
		stockUniverse.put("TSLA", new Stock("TSLA", 450.0, .07, .4));
		stockUniverse.put("GOOG", new Stock("GOOG", 130.0, .02, .2));
		stockUniverse.put("AAPL220319C00180000",
				new Option("AAPL220319C00180000", "Call", 0, 0, 0, new Stock("AAPL", 130.0, .02, .2)));

		Portfolio pf = CsvPortfolioReader.readPortfolioPositions(stockUniverse);
		List<Position> pos = pf.getPositions();

		assertEquals(3, pos.size());
		assertEquals("AAPL", pos.get(0).getSecurity().getTicker());
		assertEquals(1000, pos.get(0).getQuantity());
		assertEquals("AAPL220319C00180000", pos.get(1).getSecurity().getTicker());
		assertEquals(-20000, pos.get(1).getQuantity());
		assertEquals("TSLA", pos.get(2).getSecurity().getTicker());
		assertEquals(-500, pos.get(2).getQuantity());

	}

}
