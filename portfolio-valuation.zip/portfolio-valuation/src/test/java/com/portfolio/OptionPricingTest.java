/**
 * 
 */
package com.portfolio;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.portfolio.service.OptionPricing;

/**
 * 
 */
public class OptionPricingTest {

	@Test
	public void testCallPricing1() throws Exception {

		double callPrice = OptionPricing.calculateCallPrice(110.0, 115.0, 0.65, 0.2);
		System.out.println(callPrice);

		assertEquals("Call price is not within the expected range", 5.56, callPrice, 0.001);

	}
	
	@Test
	public void testCallPricing2() throws Exception {

		double callPrice = OptionPricing.calculateCallPrice(450.0, 460.0, 0.185, 0.4);
		System.out.println(callPrice);

		assertEquals("Call price is not within the expected range", 27.20, callPrice, 0.1);

	}
	
	@Test
	public void testPutPricing1() throws Exception {

		double callPrice = OptionPricing.calculatePutPrice(110.0, 105.0, 0.07, 0.2);
		System.out.println(callPrice);

		assertEquals("Put price is not within the expected range", 0.56, callPrice, 0.01);

	}
	
	@Test
	public void testPutPricing2() throws Exception {

		double callPrice = OptionPricing.calculatePutPrice(450.0, 440.0, 0.023, 0.4);
		System.out.println(callPrice);

		assertEquals("Put price is not within the expected range", 6.4, callPrice, 0.1);

	}

}
