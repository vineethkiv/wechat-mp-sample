-- Create table for Securities
DROP TABLE IF EXISTS securities;
CREATE TABLE IF NOT EXISTS securities (
   id BIGINT PRIMARY KEY AUTO_INCREMENT,
   ticker VARCHAR(20) NOT NULL,
   category VARCHAR(5) NOT NULL CHECK (category IN ('Stock', 'Call', 'Put')),
   price DECIMAL(10, 2),
   mu DECIMAL(5, 2),			 -- Only applicable for stock
   sigma DECIMAL(5, 2),			 -- Only applicable for stock
   strike DECIMAL(10, 2),        -- Only applicable for options
   maturity DECIMAL(5, 3),       -- Only applicable for options
   underlying VARCHAR(20)  		 -- Only applicable for options
);

-- Insert a Stock
INSERT INTO securities (ticker, category, price, mu, sigma) VALUES ('AAPL', 'Stock', 110.00, 0.04, 0.2);
-- Insert an Option
INSERT INTO securities (ticker, category, price, strike, maturity, underlying) VALUES ('AAPL220319C00180000', 'Call', 1.00, 115.00, 0.65, 'AAPL');
-- Insert an Option
INSERT INTO securities (ticker, category, price, strike, maturity, underlying) VALUES ('AAPL220319P00180000', 'Put', 1.00, 105.00, 0.07, 'AAPL');
-- Insert a Stock
INSERT INTO securities (ticker, category, price, mu, sigma) VALUES ('TSLA', 'Stock', 450.00, 0.07, 0.4);
-- Insert an Option
INSERT INTO securities (ticker, category, price, strike, maturity, underlying) VALUES ('TSLA210319C00300000', 'Call', 1.00, 460.00, 0.185, 'TSLA');
-- Insert an Option
INSERT INTO securities (ticker, category, price, strike, maturity, underlying) VALUES ('TSLA210319P00300000', 'Put', 1.00, 440.00, 0.023, 'TSLA');
-- Insert a Stock
INSERT INTO securities (ticker, category, price, mu, sigma) VALUES ('GOOG', 'Stock', 179.58, 0.02, 0.2);
-- Insert an Option
INSERT INTO securities (ticker, category, price, strike, maturity, underlying) VALUES ('GOOG241122C00190000', 'Call', 1.00, 190.00, 1, 'GOOG');
-- Insert an Option
INSERT INTO securities (ticker, category, price, strike, maturity, underlying) VALUES ('GOOG241122P00190000', 'Put', 1.00, 190.00, 1, 'GOOG');
