CREATE TABLE IF NOT EXISTS securities (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    ticker VARCHAR(10) NOT NULL,
    type VARCHAR(10) NOT NULL CHECK (type IN ('Stock', 'Call', 'Put')),
    mu DECIMAL(10, 2),				 -- Only applicable for stock
    sigma DECIMAL(10, 2),			 -- Only applicable for stock
    strike DECIMAL(10, 2),           -- Only applicable for options
    maturity DECIMAL(10, 2),         -- Only applicable for options
    underlying VARCHAR(10) NOT NULL  -- Only applicable for options
);