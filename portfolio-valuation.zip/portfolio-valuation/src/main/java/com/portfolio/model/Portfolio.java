/**
 * 
 */
package com.portfolio.model;

import java.util.List;

/**
 * 
 */
public class Portfolio {

	private List<Position> positions;

	public Portfolio(List<Position> positions) {
		this.positions = positions;
	}

	public List<Position> getPositions() {
		return positions;
	}

	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}

}
