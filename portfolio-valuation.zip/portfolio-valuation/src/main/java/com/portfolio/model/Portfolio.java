/**
 * 
 */
package com.portfolio.model;

import java.util.List;

/**
 * 
 */
public class Portfolio {

	private List<Position> positions; // List of positions in the portfolio
	private double nav;

	public Portfolio(List<Position> positions) {
		this.positions = positions;
	}

	// Getters and Setters
	public List<Position> getPositions() {
		return positions;
	}

	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}

	public double getNav() {
		return nav;
	}

	public void setNav(double nav) {
		this.nav = nav;
	}

}
