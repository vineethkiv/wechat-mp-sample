/**
 * 
 */
package com.portfolio.model;

/**
 * 
 */
public class Position {

	private Security security; // Ticker symbol of the security
	private int quantity; // Number of shares or contracts

	public Position(Security security, int quantity) {
		this.security = security;
		this.quantity = quantity;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
