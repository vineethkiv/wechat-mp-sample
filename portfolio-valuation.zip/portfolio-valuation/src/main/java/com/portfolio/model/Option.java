/**
 * 
 */
package com.portfolio.model;

/**
 * 
 */
public class Option extends Security {

	private double strike;
	private double maturity;
	private String type;
	private Stock underlying;

	public Option(String ticker, String type, double price, double strike, double maturity, Stock underlying) {
		super(ticker, price);
		this.type = type;
		this.strike = strike;
		this.maturity = maturity;
		this.underlying = underlying;
	}

	public double getStrike() {
		return strike;
	}

	public void setStrike(double strike) {
		this.strike = strike;
	}

	public double getMaturity() {
		return maturity;
	}

	public void setMaturity(double maturity) {
		this.maturity = maturity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Stock getUnderlying() {
		return underlying;
	}

	public void setUnderlying(Stock underlying) {
		this.underlying = underlying;
	}

}
