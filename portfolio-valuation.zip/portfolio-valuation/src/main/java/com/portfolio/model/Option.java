/**
 * 
 */
package com.portfolio.model;

/**
 * 
 */
public class Option extends Security {

	//private double price;
	private double strike = 100.0; // Strike price of the option
	private double maturity = 1.0; // time to maturity of the option in years
	private String type; // call or put
	private Stock underlying = new Stock("AAPL", 150.25, 0.05, 0.2); // underlying stock

	public Option(String ticker) {
		super(ticker);
	}

	public Option(String ticker, String type) {
		super(ticker);
		this.type = type;
	}

	public double getStrike() {
		return strike;
	}

	public void setStrike(double strike) {
		this.strike = strike;
	}

	public double getMaturity() {
		return maturity;
	}

	public void setMaturity(double maturity) {
		this.maturity = maturity;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Stock getUnderlying() {
		return underlying;
	}

	public void setUnderlying(Stock underlying) {
		this.underlying = underlying;
	}

}
