/**
 * 
 */
package com.portfolio.model;

/**
 * 
 */
public class Stock extends Security {

	//private double price; // Current market price of the stock
	private double mu; // expected return
	private double sigma; // volatility

	public Stock(String ticker) {
		super(ticker);
	}
	
	public Stock(String ticker, double price, double mu, double sigma) {
		super(ticker, price);
		this.mu = mu;
		this.sigma = sigma;
	}
	
	public double getMu() {
		return mu;
	}

	public void setMu(double mu) {
		this.mu = mu;
	}

	public double getSigma() {
		return sigma;
	}

	public void setSigma(double sigma) {
		this.sigma = sigma;
	}

}
