/**
 * 
 */
package com.portfolio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 */
public class Portfolio {
	
	private Map<String, Integer> positions; // symbol -> position size

    public Portfolio() {
        positions = new HashMap<>();
        loadPositionsFromCSV("src/main/resources/positions.csv");
    }

    private void loadPositionsFromCSV(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                positions.put(parts[0], Integer.parseInt(parts[1]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	/*
	 * public void updateMarketValue(RandomMarketDataProvider marketDataProvider) {
	 * System.out.println("Hello"); double totalNAV = 0; for (Map.Entry<String,
	 * Integer> entry : positions.entrySet()) { String symbol = entry.getKey(); int
	 * size = entry.getValue(); double currentPrice =
	 * marketDataProvider.getCurrentPrice(); double marketValue = size *
	 * currentPrice; totalNAV += marketValue; System.out.println("Market Value of "
	 * + symbol + ": " + marketValue); } System.out.println("Total NAV: " +
	 * totalNAV); }
	 */

}
