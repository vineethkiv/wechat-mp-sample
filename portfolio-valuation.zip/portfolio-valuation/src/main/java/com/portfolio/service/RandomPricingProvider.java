/**
 * 
 */
package com.portfolio.service;

import java.util.Random;

import com.portfolio.model.Stock;

/**
 * 
 */
public class RandomPricingProvider implements MarketDataProvider {

	private Random random = new Random();

	@Override
	public double getPrice(Stock stock) {

		double dt = 0.5 + (1.5 * random.nextDouble()); // Random time between 0.5 and 2 seconds
		double epsilon = random.nextGaussian();
		double price = stock.getPrice();

		// as per the formula shared in the problem
		double change = price
				* ((stock.getMu() * (dt / 7257600)) + ((stock.getSigma() * epsilon) * Math.sqrt(dt / 7257600)));

		return price + change;
	}

}
