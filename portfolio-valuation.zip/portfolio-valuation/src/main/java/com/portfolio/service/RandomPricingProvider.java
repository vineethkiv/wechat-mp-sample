/**
 * 
 */
package com.portfolio.service;

import java.util.Random;

import com.portfolio.model.Stock;

/**
 * 
 */
public class RandomPricingProvider implements MarketDataProvider {

	private Random random = new Random();

	@Override
	public double getPrice(Stock stock) {

		double dt = 0.5 + random.nextDouble(); // Random time between 0.5 and 2 seconds
		double epsilon = random.nextGaussian(); // Standard normal variable
		double price = stock.getPrice();
		// Update price using Geometric Brownian Motion formula
		price *= Math.exp((stock.getMu() - 0.5 * stock.getSigma() * stock.getSigma()) * dt
				+ stock.getSigma() * epsilon * Math.sqrt(dt));

		return price;
	}

}
