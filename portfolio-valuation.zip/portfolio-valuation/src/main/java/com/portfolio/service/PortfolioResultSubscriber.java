/**
 * 
 */
package com.portfolio.service;

import java.util.concurrent.BlockingQueue;

import com.portfolio.model.Option;
import com.portfolio.model.Portfolio;
import com.portfolio.model.Position;
import com.portfolio.model.Security;
import com.portfolio.model.Stock;

/**
 * 
 */
public class PortfolioResultSubscriber implements Runnable {

	private final BlockingQueue<Portfolio> pfQueue;

	public PortfolioResultSubscriber(BlockingQueue<Portfolio> pfQueue) {
		this.pfQueue = pfQueue;
	}

	@Override
	public void run() {

		try {
			while (true) {

				Portfolio pf = pfQueue.take(); // Listen for upated portfolio from the queue
				System.out.println("## Portfolio");

				double totalVal = 0.0; // TODO: change this as a published data

				System.out.printf("%-30s %-10s %-20s %-20s%n", "symbol", "price", "qty", "value");
				System.out.println("----------------------------------------------------------------------------");

				for (Position position : pf.getPositions()) {
					int qty = position.getQuantity();
					double price = 0.0;
					Security s = position.getSecurity();
					if (s instanceof Stock) {
						price = ((Stock) s).getPrice();
					} else if (s instanceof Option) {
						price = ((Option) s).getPrice();
					}
					double value = qty * price;
					System.out.printf("%-30s %-10.2f %,-20.2f %,-20.2f%n", s.getTicker(), price, (double) qty, value);
					totalVal += value;
				}
				System.out.println("");
				System.out.printf("%-30s %-10s %-20s %,-20.2f%n", "#Total Portfolio", "", "", totalVal);
				System.out.println("");
				System.out.println("");

			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

	}

}
