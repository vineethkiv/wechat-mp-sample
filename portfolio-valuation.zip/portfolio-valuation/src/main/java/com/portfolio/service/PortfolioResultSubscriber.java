/**
 * 
 */
package com.portfolio.service;

import static com.portfolio.config.Constants.EMPTY;
import static com.portfolio.config.Constants.PRICE;
import static com.portfolio.config.Constants.PRINT_DATA;
import static com.portfolio.config.Constants.PRINT_FOOTER;
import static com.portfolio.config.Constants.PRINT_HEADER;
import static com.portfolio.config.Constants.PRINT_NAV;
import static com.portfolio.config.Constants.PRINT_TABLE;
import static com.portfolio.config.Constants.QTY;
import static com.portfolio.config.Constants.SYMBOL;
import static com.portfolio.config.Constants.TABLE_LINE;
import static com.portfolio.config.Constants.VALUE;

import java.util.concurrent.BlockingQueue;

import com.portfolio.model.Portfolio;
import com.portfolio.model.Position;
import com.portfolio.model.Security;

/**
 * 
 */
public class PortfolioResultSubscriber implements Runnable {

	private final BlockingQueue<Portfolio> pfQueue;

	public PortfolioResultSubscriber(BlockingQueue<Portfolio> pfQueue) {
		this.pfQueue = pfQueue;
	}

	@Override
	public void run() {

		try {
			while (true) {

				Portfolio pf = pfQueue.take(); // Listen for updated portfolio
				System.out.println(PRINT_HEADER);

				double totalVal = 0.0;

				System.out.printf(PRINT_TABLE, SYMBOL, PRICE, QTY, VALUE);
				System.out.println(TABLE_LINE);

				for (Position position : pf.getPositions()) {
					int qty = position.getQuantity();
					Security s = position.getSecurity();
					double price = s.getPrice();
					double value = Math.round(price * 100.0)/100.0 * qty;
					System.out.printf(PRINT_DATA, s.getTicker(), price, (double) qty, value);
					totalVal += value;
				}
				System.out.println(TABLE_LINE);
				System.out.printf(PRINT_NAV, PRINT_FOOTER, EMPTY, EMPTY, totalVal);
				System.out.println(EMPTY);
				System.out.println(EMPTY);

			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

	}

}
