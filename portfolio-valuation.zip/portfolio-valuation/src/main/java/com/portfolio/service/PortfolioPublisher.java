/**
 * 
 */
package com.portfolio.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

import com.portfolio.model.Option;
import com.portfolio.model.Portfolio;
import com.portfolio.model.Position;
import com.portfolio.model.Stock;

/**
 * 
 */
public class PortfolioPublisher implements Runnable {

	private final List<Position> positions;
	private final BlockingQueue<Map<String, Double>> mdQueue;
	private final BlockingQueue<Portfolio> pfQueue;

	public PortfolioPublisher(List<Position> positions, BlockingQueue<Map<String, Double>> mdQueue,
			BlockingQueue<Portfolio> pfQueue) {
		this.positions = positions;
		this.mdQueue = mdQueue;
		this.pfQueue = pfQueue;
	}

	@Override
	public void run() {

		try {
			while (true) {

				Map<String, Double> mdUpdate = mdQueue.take(); // Listen for new market data

				List<Position> updPositions = new ArrayList<Position>(positions.size());

				for (Position position : positions) {

					// this is a common stock - check if stock has new price
					if (position.getSecurity() instanceof Stock) {
						if (mdUpdate.containsKey(position.getSecurity().getTicker())) {
							double newPrice = mdUpdate.get(position.getSecurity().getTicker());
							position.getSecurity().setPrice(newPrice);
						}
					}

					// this is an option - check if underlying stock has new price
					else if (position.getSecurity() instanceof Option
							&& mdUpdate.containsKey(((Option) position.getSecurity()).getUnderlying().getTicker())) {

						Option op = (Option) position.getSecurity();
						double underlyingPrice = mdUpdate.get(op.getUnderlying().getTicker());

						// option pricing calculation
						double newPrice = 0.0;
						if (op.getType().equals("Call")) {
							newPrice = OptionPricing.calculateCallPrice(underlyingPrice, op.getStrike(),
									op.getMaturity(), op.getUnderlying().getSigma());
						} else if (op.getType().equals("Put")) {
							newPrice = OptionPricing.calculatePutPrice(underlyingPrice, op.getStrike(),
									op.getMaturity(), op.getUnderlying().getSigma());
						}
						position.getSecurity().setPrice(newPrice);
					}

					updPositions.add(position);
				}

				// publish new portfolio
				pfQueue.put(new Portfolio(updPositions));

			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}

	}

}
