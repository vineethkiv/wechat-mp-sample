/**
 * 
 */
package com.portfolio.service;

import com.portfolio.model.Stock;

/**
 * 
 */
public interface MarketDataProvider {

	double getPrice(Stock ticker);

}
