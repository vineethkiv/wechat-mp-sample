/**
 * 
 */
package com.portfolio.service;

import static com.portfolio.config.Constants.PRINT_MDCHANGE;
import static com.portfolio.config.Constants.PRINT_MDUPDATE;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.BlockingQueue;
import java.util.stream.Collectors;

import com.portfolio.model.Stock;

/**
 * 
 */
public class MarketDataPublisher implements Runnable {

	private List<Stock> stockPool;
	private MarketDataProvider mdProvider;
	private final BlockingQueue<Map<String, Double>> mdQueue;

	public MarketDataPublisher(List<Stock> stockPool, BlockingQueue<Map<String, Double>> mdQueue) {
		this.stockPool = stockPool;
		this.mdQueue = mdQueue;
	}

	@Override
	public void run() {

		Random random = new Random();
		mdProvider = new RandomPricingProvider();

		int counter = 1;

		while (true) {

			System.out.printf(PRINT_MDUPDATE, counter);

			int maxSubsetSize = stockPool.size();
			int size = random.nextInt(maxSubsetSize) + 1;

			List<Stock> randomList;
			if (counter == 1) {
				randomList = stockPool;
			} else {
				Collections.shuffle(stockPool);
				randomList = stockPool.stream().unordered().limit(size).collect(Collectors.toList());
			}
			
			Map<String, Double> md = new HashMap<String, Double>();
			for (Stock stock : randomList) {
				double price = mdProvider.getPrice(stock);
				stock.setPrice(price);
				md.put(stock.getTicker(), price);
				System.out.printf(PRINT_MDCHANGE, stock.getTicker(), price);
			}
			counter++;
			try {
				System.out.println();
				mdQueue.put(md);
				Thread.sleep(500 + random.nextInt(2000)); // Sleep between 500ms to 2000ms
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			}
		}

	}

}
