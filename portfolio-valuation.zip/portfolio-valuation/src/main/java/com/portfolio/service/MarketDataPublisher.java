/**
 * 
 */
package com.portfolio.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.stream.Collectors;

import com.portfolio.model.Stock;

/**
 * 
 */
public class MarketDataPublisher implements Runnable {

	private Set<Stock> stockPool;
	private MarketDataProvider mdProvider;
	private final BlockingQueue<Map<String, Double>> mdQueue;

	public MarketDataPublisher(Set<Stock> stockPool, BlockingQueue<Map<String, Double>> mdQueue) {
		this.stockPool = stockPool;
		this.mdQueue = mdQueue;
	}

	@Override
	public void run() {

		Random random = new Random();
		mdProvider = new RandomPricingProvider();

		int counter = 1;

		while (true) {

			System.out.printf("## %d Market Data Update%n", counter);

			int maxSubsetSize = stockPool.size();
			int subsetSize = random.nextInt(maxSubsetSize) + 1;
			
			Set<Stock> randomSubset;
			if (counter == 1) {
				randomSubset = stockPool;
			} else {
				randomSubset = stockPool.stream().unordered().limit(subsetSize).collect(Collectors.toSet());
			}

			Map<String, Double> md = new HashMap<String, Double>();
			for (Stock stock : randomSubset) {
				double price = mdProvider.getPrice(stock);
				stock.setPrice(price);
				md.put(stock.getTicker(), price);
				System.out.printf("%s change to %.2f%n", stock.getTicker(), price);
			}
			counter++;
			try {
				System.out.println();
				mdQueue.put(md);
				Thread.sleep(500 + random.nextInt(1500)); // Sleep between 500ms to 2000ms
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				return;
			}
		}

	}

}
