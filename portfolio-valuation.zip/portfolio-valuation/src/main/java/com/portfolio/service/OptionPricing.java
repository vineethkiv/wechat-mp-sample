/**
 * 
 */
package com.portfolio.service;

import org.apache.commons.math3.distribution.NormalDistribution;

/**
 * 
 */
public class OptionPricing {

	private static final double RISK_FREE_RATE = 0.02; // Constant risk-free rate

	public static double calculateCallPrice(double s, double k, double t, double sigma) {

		NormalDistribution normalDist = new NormalDistribution();
		double d1 = (Math.log(s / k) + (RISK_FREE_RATE + 0.5 * sigma * sigma) * t) / (sigma * Math.sqrt(t));
		double d2 = d1 - sigma * Math.sqrt(t);
		return s * normalDist.cumulativeProbability(d1)
				- k * Math.exp(-RISK_FREE_RATE * t) * normalDist.cumulativeProbability(d2);

	}

	public static double calculatePutPrice(double s, double k, double t, double sigma) {

		NormalDistribution normalDist = new NormalDistribution();
		double d1 = (Math.log(s / k) + (RISK_FREE_RATE + 0.5 * sigma * sigma) * t) / (sigma * Math.sqrt(t));
		double d2 = d1 - sigma * Math.sqrt(t);
		return k * Math.exp(-RISK_FREE_RATE * t) * normalDist.cumulativeProbability(-d2)
				- s * normalDist.cumulativeProbability(-d1);

	}

}
