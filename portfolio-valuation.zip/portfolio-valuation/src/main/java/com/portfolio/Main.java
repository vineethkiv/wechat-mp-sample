/**
 * 
 */
package com.portfolio;

import static com.portfolio.util.CsvMarketdataReader.readMarketdata;
import static com.portfolio.util.CsvPortfolioReader.readPortfolio;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import com.portfolio.model.Portfolio;
import com.portfolio.model.Stock;
import com.portfolio.service.MarketDataPublisher;
import com.portfolio.service.PortfolioPublisher;
import com.portfolio.service.PortfolioResultSubscriber;

/**
 *
 */
public class Main {

	public static void main(String[] args) {

		// defining queues for communication
		BlockingQueue<Map<String, Double>> mdQueue = new ArrayBlockingQueue<>(10);
		BlockingQueue<Portfolio> pfQueue = new ArrayBlockingQueue<>(10);

		// load initial portfolio
		Portfolio portfolio = readPortfolio("src/main/resources/positions.csv");

		// define stock pool
		Set<Stock> stockPool = readMarketdata("src/main/resources/marketdata.csv");

		MarketDataPublisher mdPub = new MarketDataPublisher(stockPool, mdQueue);

		PortfolioPublisher pfPub = new PortfolioPublisher(portfolio.getPositions(), mdQueue, pfQueue);

		PortfolioResultSubscriber pfSub = new PortfolioResultSubscriber(pfQueue);

		// TODO: change all the threads to a pool
		Thread mdPubThread = new Thread(mdPub);
		mdPubThread.start();

		Thread pfPubThread = new Thread(pfPub);
		pfPubThread.start();

		Thread pfSubThread = new Thread(pfSub);
		pfSubThread.start();

		// For demonstration purposes, let it run for some time before stopping (e.g.,
		// 10 seconds)
		try {
			Thread.sleep(10000); // Run for 10 seconds
			mdPubThread.interrupt(); // Stop the publisher thread gracefully
			mdPubThread.join(); // Wait for the thread to finish
			System.out.println("Market data publishing stopped.");

			pfPubThread.interrupt(); // Stop the listener thread gracefully
			pfPubThread.join(); // Wait for the thread to finish
			System.out.println("Portfolio publishing stopped.");

			pfSubThread.interrupt(); // Stop the listener thread gracefully
			pfSubThread.join(); // Wait for the thread to finish
			System.out.println("Portfolio printing stopped.");
		} catch (InterruptedException e) {
			e.printStackTrace();
			Thread.currentThread().interrupt();
		}

	}

}
