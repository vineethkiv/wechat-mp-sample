/**
 * 
 */
package com.portfolio;

import static com.portfolio.util.CsvPortfolioReader.readPortfolioPositions;
import static com.portfolio.util.DatabaseUtil.getSecurities;
import static com.portfolio.util.DatabaseUtil.initializeDatabase;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.portfolio.model.Portfolio;
import com.portfolio.model.Security;
import com.portfolio.model.Stock;
import com.portfolio.service.MarketDataPublisher;
import com.portfolio.service.PortfolioPublisher;
import com.portfolio.service.PortfolioResultSubscriber;

/**
 *
 */
public class Main {

	public static void main(String[] args) {

		System.out.println("Start.......");
		System.out.println();

		// initializing security tables
		initializeDatabase();

		// load securities universe from database
		Map<String, Security> universe = getSecurities();

		// load initial portfolio from csv
		Portfolio portfolio = readPortfolioPositions(universe);

		// create stock pool from universe for market data service
		List<Stock> stockPool = universe.entrySet().stream().filter(entry -> entry.getValue() instanceof Stock)
				.map(entry -> (Stock) entry.getValue()).collect(Collectors.toList());

		BlockingQueue<Map<String, Double>> mdQueue = new ArrayBlockingQueue<>(10);
		// publish market data for stocks defined in the pool
		MarketDataPublisher mdPub = new MarketDataPublisher(stockPool, mdQueue);

		BlockingQueue<Portfolio> pfQueue = new ArrayBlockingQueue<>(10);
		// Publish the updated portfolio based on the market data change
		PortfolioPublisher pfPub = new PortfolioPublisher(portfolio.getPositions(), mdQueue, pfQueue);
		// Subscribe and print the updated portfolio
		PortfolioResultSubscriber pfSub = new PortfolioResultSubscriber(pfQueue);

		ExecutorService executor = Executors.newFixedThreadPool(3);
		Future<?> future1 = executor.submit(mdPub);
		Future<?> future2 = executor.submit(pfPub);
		Future<?> future3 = executor.submit(pfSub);

		try {
			Thread.sleep(10000);
			cancelTask(future1);
			cancelTask(future2);
			cancelTask(future3);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			System.out.println("Main thread was interrupted: " + e.getMessage());
		} finally {
			executor.shutdown();
			try {
				if (!executor.awaitTermination(60, TimeUnit.SECONDS)) {
					executor.shutdownNow();
				}
			} catch (InterruptedException e) {
				executor.shutdownNow();
				Thread.currentThread().interrupt();
			}
		}

		System.out.println("Finish!!!");

	}

	private static void cancelTask(Future<?> future) {
		if (!future.isDone()) {
			future.cancel(true);
		}
	}

}
