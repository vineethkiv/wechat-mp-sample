/**
 * 
 */
package com.portfolio.config;

/**
 * 
 */
public class Constants {

	public static final String TICKER = "ticker";
	public static final String CATEGORY = "category";
	public static final String PRICE = "price";
	public static final String MU = "mu";
	public static final String SIGMA = "sigma";
	public static final String STRIKE = "strike";
	public static final String MATURITY = "maturity";
	public static final String UNDERLYING = "underlying";
	public static final String SYMBOL = "symbol";
	public static final String QTY = "qty";
	public static final String VALUE = "value";
	public static final String DB_URL = "jdbc:h2:~/securities";
	public static final String SQL_PATH = "src/main/resources/securities.sql";
	public static final String USER = "sa";
	public static final String EMPTY = "";
	public static final String STOCK_QUERY = "SELECT ticker, price, mu, sigma FROM securities where category = 'Stock'";
	public static final String OPTION_QUERY = "SELECT ticker, category, price, strike, maturity, underlying FROM securities where category != 'Stock'";
	public static final String CSV_PATH = "src/main/resources/positions.csv";
	public static final String PRINT_MDUPDATE = "## %d Market Data Update%n";
	public static final String PRINT_MDCHANGE = "%s change to %.2f%n";
	public static final String PRINT_HEADER = "## Portfolio";
	public static final String PRINT_TABLE = "%-25s %10s %15s %20s%n";
	public static final String TABLE_LINE = "----------------------------------------------------------------------------";
	public static final String PRINT_DATA = "%-25s %10.2f %,15.2f %,20.2f%n";
	public static final String PRINT_NAV = "%-25s %10s %15s %,20.2f%n";
	public static final String PRINT_FOOTER = "#Total Portfolio";

}
