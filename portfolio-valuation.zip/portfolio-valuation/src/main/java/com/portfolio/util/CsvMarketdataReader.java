package com.portfolio.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import com.portfolio.model.Stock;

public class CsvMarketdataReader {

	public static Set<Stock> readMarketdata(String filePath) {
		Set<Stock> data = new HashSet<Stock>();
		String line;

		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			// Read header line
			br.readLine(); // Skip the header line

			while ((line = br.readLine()) != null) {
				String[] values = line.split(",");

				if (values.length < 4) {
					continue; // Skip incomplete lines
				}

				String ticker = values[0].trim();
				double price = Double.parseDouble(values[1].trim());
				double mu = Double.parseDouble(values[2].trim());
				double sigma = Double.parseDouble(values[3].trim());

				Stock s = new Stock(ticker);
				s.setPrice(price);
				s.setMu(mu);
				s.setSigma(sigma);
				data.add(s);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return data;
	}

}
