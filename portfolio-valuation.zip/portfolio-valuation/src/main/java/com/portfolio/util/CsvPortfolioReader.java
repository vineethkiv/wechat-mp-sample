/**
 * 
 */
package com.portfolio.util;

import static com.portfolio.config.Constants.CSV_PATH;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.portfolio.model.Portfolio;
import com.portfolio.model.Position;
import com.portfolio.model.Security;

/**
 * 
 */
public class CsvPortfolioReader {

	public static Portfolio readPortfolioPositions(Map<String, Security> universe) {
		
		List<Position> positions = new ArrayList<>();
		String line;

		try (BufferedReader br = new BufferedReader(new FileReader(CSV_PATH))) {

			br.readLine(); // skip header

			while ((line = br.readLine()) != null) {
				String[] values = line.split(",");

				// ignoring incomplete position entries
				if (values.length < 2) {
					continue;
				}

				String type = values[0].trim();
				String ticker = values[0].trim();
				int quantity = Integer.parseInt(values[1].trim());

				// accept only securities available in the defined universe
				if (universe.containsKey(ticker)) {
					positions.add(new Position(universe.get(ticker), quantity));
				} else {
					System.out.println("Unknown type: " + type);
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return new Portfolio(positions);
	}

}
