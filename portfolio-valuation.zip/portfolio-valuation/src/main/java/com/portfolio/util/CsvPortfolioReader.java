/**
 * 
 */
package com.portfolio.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.portfolio.model.Option;
import com.portfolio.model.Portfolio;
import com.portfolio.model.Position;
import com.portfolio.model.Stock;

/**
 * 
 */
public class CsvPortfolioReader {

	public static Portfolio readPortfolio(String filePath) {
		List<Position> positions = new ArrayList<>();
		String line;

		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			// Read header line
			br.readLine(); // Skip the header line

			while ((line = br.readLine()) != null) {
				String[] values = line.split(",");

				if (values.length < 3) {
					continue; // Skip incomplete lines
				}

				String type = values[0].trim();
				String ticker = values[1].trim();
				int quantity = Integer.parseInt(values[2].trim());

				switch (type) {
				case "Call":
				case "Put":
					Option po = new Option(ticker, type);
					positions.add(new Position(po, quantity));
					break;
				case "Stock":
					Stock st = new Stock(ticker);
					positions.add(new Position(st, quantity));
					break;
				default:
					System.out.println("Unknown type: " + type);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return new Portfolio(positions);
	}

}
