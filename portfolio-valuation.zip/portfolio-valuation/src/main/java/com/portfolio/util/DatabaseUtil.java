/**
 * 
 */
package com.portfolio.util;

import static com.portfolio.config.Constants.CATEGORY;
import static com.portfolio.config.Constants.DB_URL;
import static com.portfolio.config.Constants.EMPTY;
import static com.portfolio.config.Constants.MATURITY;
import static com.portfolio.config.Constants.MU;
import static com.portfolio.config.Constants.OPTION_QUERY;
import static com.portfolio.config.Constants.PRICE;
import static com.portfolio.config.Constants.SIGMA;
import static com.portfolio.config.Constants.SQL_PATH;
import static com.portfolio.config.Constants.STOCK_QUERY;
import static com.portfolio.config.Constants.STRIKE;
import static com.portfolio.config.Constants.TICKER;
import static com.portfolio.config.Constants.UNDERLYING;
import static com.portfolio.config.Constants.USER;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.portfolio.model.Option;
import com.portfolio.model.Security;
import com.portfolio.model.Stock;

/**
 * 
 */
public class DatabaseUtil {

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(DB_URL, USER, EMPTY);
	}

	public static void initializeDatabase() {

		try (BufferedReader br = new BufferedReader(new FileReader(SQL_PATH))) {
			String line;
			StringBuilder sql = new StringBuilder();
			while ((line = br.readLine()) != null) {
				sql.append(line).append("\n");
			}

			Connection conn = getConnection();
			Statement statement = conn.createStatement();
			statement.execute(sql.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Map<String, Security> getSecurities() {

		Map<String, Security> universe = new HashMap<String, Security>();

		try (Connection conn = getConnection();
				Statement statement = conn.createStatement();
				ResultSet stockRs = statement.executeQuery(STOCK_QUERY);
				Statement statement2 = conn.createStatement();
				ResultSet optionsRs = statement2.executeQuery(OPTION_QUERY);) {

			Map<String, Security> stocks = new HashMap<String, Security>();
			while (stockRs.next()) {
				String ticker = stockRs.getString(TICKER);
				double price = stockRs.getDouble(PRICE);
				double mu = stockRs.getDouble(MU);
				double sigma = stockRs.getDouble(SIGMA);
				Security stock = new Stock(ticker, price, mu, sigma);
				stocks.put(ticker, stock);
				universe.put(ticker, stock);
			}

			while (optionsRs.next()) {
				String ticker = optionsRs.getString(TICKER);
				String category = optionsRs.getString(CATEGORY);
				double price = optionsRs.getDouble(PRICE);
				double strike = optionsRs.getDouble(STRIKE);
				double maturity = optionsRs.getDouble(MATURITY);
				String underlying = optionsRs.getString(UNDERLYING);
				Stock uStock = (Stock) stocks.get(underlying);
				Security option = new Option(ticker, category, price, strike, maturity, uStock);
				universe.put(ticker, option);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return universe;
	}

}
